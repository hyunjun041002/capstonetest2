import express from 'express'
import bodyParser from 'body-parser'
import authRouter from './routes/auth.js'

const app = express()
const port = process.env.PORT || 3000

// ── 미들웨어 ──────────────────────────────
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))

// ── 라우터 ───────────────────────────────
app.use('/api/auth', authRouter)

// ── 기본 헬스 체크 ───────────────────────
app.get('/', (req, res) => {
  res.json({ message: '학과 챗봇 API 서버 정상 동작 중' })
})

app.listen(port, () => {
  console.log(`서버 실행 중: http://localhost:${port}`)
})
