import axios from 'axios';
import * as cheerio from 'cheerio';

async function getNotice() {
  try {
    const url = 'https://www.jeiu.ac.kr/software/cms/FrBoardCon/BoardView.do?MENU_ID=320'; 
    
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });

    const $ = cheerio.load(response.data);

    console.log("--- 데이터 수집 시도 중 ---");

    const notices = [];
    $('table tbody tr').each((i, el) => {
      const title = $(el).find('td.subject a, td.title a, a').first().text().trim();
      if (title) {
        notices.push(title);
      }
    });

    if (notices.length === 0) {
      console.log("데이터를 찾지 못했습니다.");
      console.log("받아온 HTML 일부:", $.html().substring(0, 1000)); 
    } else {
      notices.forEach((t, idx) => console.log(`${idx + 1}. ${t}`));
      console.log("--- 수집 완료 ---");
    }

  } catch (error) {
    console.error("오류 발생:", error.message);
  }
}

getNotice();