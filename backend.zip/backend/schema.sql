-- 데이터베이스 생성
CREATE DATABASE IF NOT EXISTS chatbot_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE chatbot_db;

-- 사용자 테이블
CREATE TABLE IF NOT EXISTS users (
  id          INT          AUTO_INCREMENT PRIMARY KEY,
  student_id  VARCHAR(20)  NOT NULL UNIQUE COMMENT '학번',
  grade       TINYINT      NOT NULL       COMMENT '학년 (1~4)',
  class_num   TINYINT      NOT NULL       COMMENT '반',
  password    VARCHAR(255) NOT NULL       COMMENT 'bcrypt 해시',
  created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP
);
