import express from 'express'
import bcrypt from 'bcrypt'
import db from '../db.js'

const router = express.Router()
const SALT_ROUNDS = 10

// ──────────────────────────────────────────
// POST /api/auth/register  (회원가입)
// body: { student_id, grade, class_num, password }
// ──────────────────────────────────────────
router.post('/register', async (req, res) => {
  const { student_id, grade, class_num, password } = req.body

  if (!student_id || !grade || !class_num || !password) {
    return res.status(400).json({ message: '모든 항목을 입력해주세요.' })
  }

  try {
    // 학번 중복 확인
    const [rows] = await db.query(
      'SELECT id FROM users WHERE student_id = ?',
      [student_id]
    )
    if (rows.length > 0) {
      return res.status(409).json({ message: '이미 등록된 학번입니다.' })
    }

    const hashed = await bcrypt.hash(password, SALT_ROUNDS)

    await db.query(
      'INSERT INTO users (student_id, grade, class_num, password) VALUES (?, ?, ?, ?)',
      [student_id, grade, class_num, hashed]
    )

    return res.status(201).json({ message: '회원가입이 완료되었습니다.' })
  } catch (err) {
    console.error('register error:', err)
    return res.status(500).json({ message: '서버 오류가 발생했습니다.' })
  }
})

// ──────────────────────────────────────────
// POST /api/auth/login  (로그인)
// body: { student_id, password }
// ──────────────────────────────────────────
router.post('/login', async (req, res) => {
  const { student_id, password } = req.body

  if (!student_id || !password) {
    return res.status(400).json({ message: '학번과 비밀번호를 입력해주세요.' })
  }

  try {
    const [rows] = await db.query(
      'SELECT * FROM users WHERE student_id = ?',
      [student_id]
    )

    if (rows.length === 0) {
      return res.status(401).json({ message: '학번 또는 비밀번호가 올바르지 않습니다.' })
    }

    const user = rows[0]
    const match = await bcrypt.compare(password, user.password)

    if (!match) {
      return res.status(401).json({ message: '학번 또는 비밀번호가 올바르지 않습니다.' })
    }

    // 비밀번호 제외하고 응답
    const { password: _pw, ...safeUser } = user
    return res.status(200).json({
      message: '로그인 성공',
      user: safeUser,
    })
  } catch (err) {
    console.error('login error:', err)
    return res.status(500).json({ message: '서버 오류가 발생했습니다.' })
  }
})

export default router
